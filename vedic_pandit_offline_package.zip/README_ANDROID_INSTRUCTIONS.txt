VEDIC PANDIT — OFFLINE INSTALL

1. Extract the ZIP.
2. Open index.html in Chrome, Samsung Internet, Windows or macOS.
3. On Android Chrome use the browser menu > Add to Home screen.
4. Keep the HTML file and manifest together for the best offline experience.
